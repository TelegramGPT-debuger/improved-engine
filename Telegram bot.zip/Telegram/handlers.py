from datetime import datetime

from aiogram import (
    Router,
    F,
    Bot,
)

from aiogram.filters import CommandStart

from aiogram.fsm.context import FSMContext

from aiogram.types import (
    Message,
    FSInputFile,
    ReplyKeyboardRemove,
)

from sqlalchemy import select

from database import SessionLocal

from models import (
    User,
    Application,
)

from states import ApplicationStates

from keyboards import (
    phone_keyboard,
    category_keyboard,
    location_keyboard,
    confirmation_keyboard,
)

from dispatcher import (
    notify_dispatchers,
    google_maps_url,
)

from excel_report import (
    create_daily_report,
)

from config import DISPATCHER_IDS


router = Router()


# =========================================================
# START
# =========================================================

@router.message(CommandStart())
async def start_handler(
    message: Message,
    state: FSMContext,
):

    await state.clear()

    async with SessionLocal() as session:

        result = await session.execute(
            select(User).where(
                User.telegram_id
                == message.from_user.id
            )
        )

        user = result.scalar_one_or_none()

        if not user:

            user = User(
                telegram_id=message.from_user.id,
                full_name=message.from_user.full_name,
                username=message.from_user.username,
            )

            session.add(user)

        else:

            user.full_name = (
                message.from_user.full_name
            )

            user.username = (
                message.from_user.username
            )

        await session.commit()

    await message.answer(
        "👋 <b>Kommunal xizmatlar "
        "murojaat tizimiga xush kelibsiz!</b>\n\n"

        "Bu bot orqali kommunal muammolar "
        "haqida murojaat yuborishingiz mumkin.\n\n"

        "Masalan:\n"
        "🔥 Gaz yo'q\n"
        "💧 Suv quvuri buzilgan\n"
        "⚡ Elektr muammosi\n"
        "🚰 Kanalizatsiya muammosi\n\n"

        "Murojaat yuborish uchun "
        "telefon raqamingizni yuboring.",
        parse_mode="HTML",
        reply_markup=phone_keyboard(),
    )

    await state.set_state(
        ApplicationStates.phone
    )


# =========================================================
# PHONE
# =========================================================

@router.message(
    ApplicationStates.phone,
    F.contact,
)
async def phone_handler(
    message: Message,
    state: FSMContext,
):

    phone = message.contact.phone_number

    await state.update_data(
        phone=phone,
    )

    await message.answer(
        "🛠 <b>Muammo turini tanlang:</b>",
        parse_mode="HTML",
        reply_markup=category_keyboard(),
    )

    await state.set_state(
        ApplicationStates.category
    )


# =========================================================
# CATEGORY
# =========================================================

@router.message(
    ApplicationStates.category,
)
async def category_handler(
    message: Message,
    state: FSMContext,
):

    allowed_categories = {
        "🔥 Gaz",
        "💧 Suv",
        "⚡ Elektr",
        "🌡 Issiqlik",
        "🚰 Kanalizatsiya",
        "🏢 Boshqa",
    }

    if message.text not in allowed_categories:

        await message.answer(
            "Iltimos, quyidagi tugmalardan "
            "birini tanlang.",
            reply_markup=category_keyboard(),
        )

        return

    await state.update_data(
        category=message.text,
    )

    await message.answer(
        "📝 <b>Muammoni batafsil yozing:</b>\n\n"

        "Masalan:\n"
        "«Uyimizda ertalabdan beri "
        "gaz yo'q»",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove(),
    )

    await state.set_state(
        ApplicationStates.description
    )


# =========================================================
# DESCRIPTION
# =========================================================

@router.message(
    ApplicationStates.description,
)
async def description_handler(
    message: Message,
    state: FSMContext,
):

    if not message.text:

        await message.answer(
            "Iltimos, muammoni matn ko'rinishida "
            "yozing."
        )

        return

    if len(message.text.strip()) < 5:

        await message.answer(
            "Muammoni biroz batafsilroq "
            "yozing."
        )

        return

    await state.update_data(
        description=message.text.strip(),
    )

    await message.answer(
        "📍 <b>Muammo joylashgan joyning "
        "lokatsiyasini yuboring.</b>\n\n"

        "Quyidagi tugmani bosing:",
        parse_mode="HTML",
        reply_markup=location_keyboard(),
    )

    await state.set_state(
        ApplicationStates.location
    )


# =========================================================
# LOCATION
# =========================================================

@router.message(
    ApplicationStates.location,
    F.location,
)
async def location_handler(
    message: Message,
    state: FSMContext,
):

    latitude = message.location.latitude

    longitude = message.location.longitude

    await state.update_data(
        latitude=latitude,
        longitude=longitude,
    )

    maps_url = google_maps_url(
        latitude,
        longitude,
    )

    await message.answer(
        "✅ <b>Lokatsiya qabul qilindi.</b>\n\n"

        f"Latitude: <code>{latitude}</code>\n"
        f"Longitude: <code>{longitude}</code>\n\n"

        f"🗺 <a href=\"{maps_url}\">"
        "Xaritada ko'rish"
        "</a>\n\n"

        "Endi muammo rasmini yuboring 📷\n\n"

        "Agar rasm bo'lmasa, "
        "<b>Rasm yo'q</b> deb yozing.",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove(),
    )

    await state.set_state(
        ApplicationStates.photo
    )


@router.message(
    ApplicationStates.location,
)
async def wrong_location_handler(
    message: Message,
):

    await message.answer(
        "📍 Iltimos, aynan "
        "«📍 Joylashuvimni yuborish» "
        "tugmasini bosing."
    )


# =========================================================
# PHOTO
# =========================================================

@router.message(
    ApplicationStates.photo,
    F.photo,
)
async def photo_handler(
    message: Message,
    state: FSMContext,
):

    photo = message.photo[-1]

    await state.update_data(
        photo_file_id=photo.file_id,
    )

    await show_confirmation(
        message,
        state,
    )


@router.message(
    ApplicationStates.photo,
    F.text.casefold() == "rasm yo'q",
)
async def no_photo_handler(
    message: Message,
    state: FSMContext,
):

    await state.update_data(
        photo_file_id=None,
    )

    await show_confirmation(
        message,
        state,
    )


@router.message(
    ApplicationStates.photo,
)
async def wrong_photo_handler(
    message: Message,
):

    await message.answer(
        "📷 Iltimos, muammo rasmini yuboring.\n\n"
        "Agar rasm bo'lmasa:\n"
        "<b>Rasm yo'q</b>\n"
        "deb yozing.",
        parse_mode="HTML",
    )


# =========================================================
# CONFIRMATION
# =========================================================

async def show_confirmation(
    message: Message,
    state: FSMContext,
):

    data = await state.get_data()

    maps_url = google_maps_url(
        data["latitude"],
        data["longitude"],
    )

    text = (
        "📋 <b>MUROJAAT MA'LUMOTLARI</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"

        f"📞 Telefon:\n"
        f"<b>{data['phone']}</b>\n\n"

        f"🛠 Muammo turi:\n"
        f"<b>{data['category']}</b>\n\n"

        f"📝 Muammo:\n"
        f"{data['description']}\n\n"

        f"📍 Lokatsiya:\n"
        f"<code>{data['latitude']}, "
        f"{data['longitude']}</code>\n\n"

        f"🗺 <a href=\"{maps_url}\">"
        "Xaritada ochish"
        "</a>\n\n"

        f"📷 Foto: "
        f"{'Bor' if data.get('photo_file_id') else 'Yo‘q'}\n\n"

        "━━━━━━━━━━━━━━━━━━\n"
        "Ma'lumotlar to'g'rimi?"
    )

    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=confirmation_keyboard(),
    )

    await state.set_state(
        ApplicationStates.confirmation
    )


# =========================================================
# SAVE APPLICATION
# =========================================================

@router.message(
    ApplicationStates.confirmation,
    F.text == "✅ Tasdiqlash",
)
async def save_application(
    message: Message,
    state: FSMContext,
    bot: Bot,
):

    data = await state.get_data()

    async with SessionLocal() as session:

        # USER
        result = await session.execute(
            select(User).where(
                User.telegram_id
                == message.from_user.id
            )
        )

        user = result.scalar_one_or_none()

        if not user:

            user = User(
                telegram_id=message.from_user.id,
                full_name=message.from_user.full_name,
                username=message.from_user.username,
                phone=data["phone"],
            )

            session.add(user)

            await session.flush()

        else:

            user.phone = data["phone"]

            user.full_name = (
                message.from_user.full_name
            )

            user.username = (
                message.from_user.username
            )

        # APPLICATION NUMBER
        now = datetime.now()

        application_number = (
            f"KM-"
            f"{now.strftime('%Y%m%d')}-"
            f"{now.strftime('%H%M%S')}-"
            f"{message.from_user.id % 10000:04d}"
        )

        application = Application(
            application_number=application_number,

            user_id=user.id,

            category=data["category"],

            description=data["description"],

            latitude=data["latitude"],

            longitude=data["longitude"],

            photo_file_id=data.get(
                "photo_file_id"
            ),

            status="new",
        )

        session.add(application)

        await session.commit()

        await session.refresh(application)

        await session.refresh(user)

    # DISPATCHERGA YUBORISH
    await notify_dispatchers(
        bot=bot,
        application=application,
        user=user,
    )

    await message.answer(
        "✅ <b>MUROJAATINGIZ QABUL QILINDI!</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"

        f"🆔 Murojaat raqami:\n"
        f"<code>{application_number}</code>\n\n"

        "📨 Murojaatingiz dispecherga "
        "yuborildi.\n\n"

        "Mutasaddi xodimlar murojaatingizni "
        "ko'rib chiqadi.\n\n"

        "Murojaat raqamingizni saqlab qo'ying.",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove(),
    )

    await state.clear()


# =========================================================
# CANCEL
# =========================================================

@router.message(
    ApplicationStates.confirmation,
    F.text == "❌ Bekor qilish",
)
async def cancel_application(
    message: Message,
    state: FSMContext,
):

    await state.clear()

    await message.answer(
        "❌ Murojaat bekor qilindi.\n\n"
        "Qaytadan murojaat yuborish uchun "
        "/start buyrug'ini bosing.",
        reply_markup=ReplyKeyboardRemove(),
    )


# =========================================================
# MY APPLICATIONS
# =========================================================

@router.message(F.text == "/my")
async def my_applications(
    message: Message,
):

    async with SessionLocal() as session:

        result = await session.execute(
            select(
                Application
            )
            .join(
                User,
                Application.user_id == User.id,
            )
            .where(
                User.telegram_id
                == message.from_user.id
            )
            .order_by(
                Application.created_at.desc()
            )
            .limit(10)
        )

        applications = result.scalars().all()

    if not applications:

        await message.answer(
            "Sizda hali murojaatlar mavjud emas."
        )

        return

    text = (
        "📋 <b>SO'NGGI MUROJAATLARINGIZ</b>\n\n"
    )

    status_names = {
        "new": "🆕 Yangi",
        "accepted": "📥 Qabul qilindi",
        "assigned": "👷 Brigadaga biriktirildi",
        "in_progress": "🔧 Jarayonda",
        "completed": "✅ Tugallandi",
        "closed": "🔒 Yopildi",
        "cancelled": "❌ Bekor qilindi",
    }

    for application in applications:

        status = status_names.get(
            application.status,
            application.status,
        )

        text += (
            f"🆔 <code>"
            f"{application.application_number}"
            f"</code>\n"

            f"🛠 {application.category}\n"

            f"📊 {status}\n"

            f"🕐 "
            f"{application.created_at.strftime('%d.%m.%Y %H:%M')}"
            f"\n\n"
        )

    await message.answer(
        text,
        parse_mode="HTML",
    )


# =========================================================
# REPORT
# =========================================================

@router.message(
    F.text == "/report"
)
async def report_handler(
    message: Message,
):

    if message.from_user.id not in DISPATCHER_IDS:

        await message.answer(
            "⛔ Bu buyruq faqat "
            "dispecherlar uchun."
        )

        return

    await message.answer(
        "⏳ Bugungi hisobot tayyorlanmoqda..."
    )

    try:

        filename = (
            await create_daily_report()
        )

        document = FSInputFile(
            filename
        )

        await message.answer_document(
            document=document,
            caption=(
                "📊 <b>Bugungi murojaatlar "
                "hisoboti</b>"
            ),
            parse_mode="HTML",
        )

    except Exception as error:

        await message.answer(
            "❌ Hisobot yaratishda xatolik:\n\n"
            f"<code>{error}</code>",
            parse_mode="HTML",
        )