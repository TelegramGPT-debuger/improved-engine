from aiogram.fsm.state import State, StatesGroup


class ApplicationStates(StatesGroup):

    phone = State()

    category = State()

    description = State()

    location = State()

    photo = State()

    confirmation = State()