import os

from dotenv import load_dotenv


load_dotenv()


BOT_TOKEN = os.getenv("BOT_TOKEN")

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite+aiosqlite:///kommunal.db"
)

DISPATCHER_IDS = [
    int(user_id.strip())
    for user_id in os.getenv(
        "DISPATCHER_IDS",
        ""
    ).split(",")
    if user_id.strip()
]


if not BOT_TOKEN:
    raise ValueError(
        "BOT_TOKEN .env faylida topilmadi!"
    )