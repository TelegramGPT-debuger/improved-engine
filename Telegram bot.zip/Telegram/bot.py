import asyncio
import logging
import os

from aiogram import (
    Bot,
    Dispatcher,
)

from config import BOT_TOKEN

from database import engine

from models import Base

from handlers import router


logging.basicConfig(
    level=logging.INFO,
)


async def init_database():

    os.makedirs(
        "reports",
        exist_ok=True,
    )

    os.makedirs(
        "uploads",
        exist_ok=True,
    )

    os.makedirs(
        "uploads/applications",
        exist_ok=True,
    )

    async with engine.begin() as connection:

        await connection.run_sync(
            Base.metadata.create_all
        )


async def main():

    print("=" * 60)

    print(
        "KOMMUNAL MUROJAATLAR TIZIMI"
    )

    print(
        "TEST VERSION"
    )

    print("=" * 60)

    await init_database()

    bot = Bot(
        token=BOT_TOKEN
    )

    dp = Dispatcher()

    dp.include_router(router)

    print(
        "✅ Database tayyor"
    )

    print(
        "✅ Telegram bot ishga tushdi"
    )

    print(
        "⏳ Xabarlar kutilmoqda..."
    )

    print("=" * 60)

    try:

        await dp.start_polling(
            bot
        )

    finally:

        await bot.session.close()


if __name__ == "__main__":

    asyncio.run(main())