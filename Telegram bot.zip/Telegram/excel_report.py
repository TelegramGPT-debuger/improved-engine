import os

from datetime import datetime, timedelta

from openpyxl import Workbook

from openpyxl.styles import (
    Font,
    Alignment,
)

from sqlalchemy import select

from database import SessionLocal

from models import (
    Application,
    User,
)


REPORTS_DIR = "reports"


async def create_daily_report():

    os.makedirs(
        REPORTS_DIR,
        exist_ok=True,
    )

    now = datetime.now()

    start_of_day = datetime(
        now.year,
        now.month,
        now.day,
    )

    end_of_day = (
        start_of_day
        + timedelta(days=1)
    )

    filename = os.path.join(
        REPORTS_DIR,
        f"murojaatlar_"
        f"{now.strftime('%Y-%m-%d')}.xlsx",
    )

    workbook = Workbook()

    sheet = workbook.active

    sheet.title = "Murojaatlar"

    headers = [
        "№",
        "Murojaat raqami",
        "Sana",
        "Vaqt",
        "F.I.Sh.",
        "Telefon",
        "Telegram ID",
        "Muammo turi",
        "Muammo tavsifi",
        "Latitude",
        "Longitude",
        "Google Maps",
        "Foto",
        "Status",
    ]

    sheet.append(headers)

    for cell in sheet[1]:

        cell.font = Font(
            bold=True
        )

        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
        )

    async with SessionLocal() as session:

        result = await session.execute(
            select(
                Application,
                User,
            )
            .join(
                User,
                Application.user_id == User.id,
            )
            .where(
                Application.created_at
                >= start_of_day,
                Application.created_at
                < end_of_day,
            )
            .order_by(
                Application.created_at.asc()
            )
        )

        rows = result.all()

        for index, (
            application,
            user,
        ) in enumerate(
            rows,
            start=1,
        ):

            maps_url = (
                "https://www.google.com/maps/search/"
                f"?api=1&query="
                f"{application.latitude},"
                f"{application.longitude}"
            )

            sheet.append([
                index,
                application.application_number,
                application.created_at.strftime(
                    "%Y-%m-%d"
                ),
                application.created_at.strftime(
                    "%H:%M:%S"
                ),
                user.full_name,
                user.phone or "",
                user.telegram_id,
                application.category,
                application.description,
                application.latitude,
                application.longitude,
                maps_url,
                "Ha"
                if application.photo_file_id
                else "Yo'q",
                application.status,
            ])

    widths = {
        "A": 8,
        "B": 28,
        "C": 15,
        "D": 12,
        "E": 25,
        "F": 20,
        "G": 18,
        "H": 20,
        "I": 50,
        "J": 15,
        "K": 15,
        "L": 50,
        "M": 10,
        "N": 20,
    }

    for column, width in widths.items():

        sheet.column_dimensions[
            column
        ].width = width

    workbook.save(filename)

    return filename