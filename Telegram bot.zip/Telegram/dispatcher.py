from aiogram import Bot

from config import DISPATCHER_IDS

from models import Application, User


def google_maps_url(
    latitude: float,
    longitude: float,
) -> str:

    return (
        "https://www.google.com/maps/search/"
        f"?api=1&query={latitude},{longitude}"
    )


async def notify_dispatchers(
    bot: Bot,
    application: Application,
    user: User,
):

    maps_url = google_maps_url(
        application.latitude,
        application.longitude,
    )

    text = (
        "🚨 <b>YANGI MUROJAAT</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"

        f"🆔 <b>{application.application_number}</b>\n\n"

        f"👤 F.I.Sh.: "
        f"<b>{user.full_name}</b>\n"

        f"📞 Telefon: "
        f"<b>{user.phone or '-'}</b>\n"

        f"👤 Telegram: "
        f"@{user.username}"
        if user.username
        else
        f"👤 Telegram ID: "
        f"<code>{user.telegram_id}</code>"
    )

    text += (
        "\n\n"
        f"🛠 Muammo turi:\n"
        f"<b>{application.category}</b>\n\n"

        f"📝 Muammo:\n"
        f"{application.description}\n\n"

        f"📍 Koordinatalar:\n"
        f"<code>{application.latitude}, "
        f"{application.longitude}</code>\n\n"

        f"🗺 <a href=\"{maps_url}\">Xaritada ochish</a>\n\n"

        f"📊 Status: "
        f"<b>Yangi</b>"
    )

    for dispatcher_id in DISPATCHER_IDS:

        try:

            if application.photo_file_id:

                await bot.send_photo(
                    chat_id=dispatcher_id,
                    photo=application.photo_file_id,
                    caption=text,
                    parse_mode="HTML",
                )

            else:

                await bot.send_message(
                    chat_id=dispatcher_id,
                    text=text,
                    parse_mode="HTML",
                    disable_web_page_preview=False,
                )

        except Exception as error:

            print(
                f"Dispecher {dispatcher_id} ga "
                f"yuborishda xato: {error}"
            )