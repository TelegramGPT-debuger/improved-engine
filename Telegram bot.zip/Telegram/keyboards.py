from aiogram.types import (
    KeyboardButton,
    ReplyKeyboardMarkup,
)


def phone_keyboard():

    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(
                    text="📞 Telefon raqamimni yuborish",
                    request_contact=True,
                )
            ]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def category_keyboard():

    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="🔥 Gaz"),
                KeyboardButton(text="💧 Suv"),
            ],
            [
                KeyboardButton(text="⚡ Elektr"),
                KeyboardButton(text="🌡 Issiqlik"),
            ],
            [
                KeyboardButton(text="🚰 Kanalizatsiya"),
                KeyboardButton(text="🏢 Boshqa"),
            ],
        ],
        resize_keyboard=True,
    )


def location_keyboard():

    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(
                    text="📍 Joylashuvimni yuborish",
                    request_location=True,
                )
            ]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def confirmation_keyboard():

    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(
                    text="✅ Tasdiqlash"
                )
            ],
            [
                KeyboardButton(
                    text="❌ Bekor qilish"
                )
            ],
        ],
        resize_keyboard=True,
    )